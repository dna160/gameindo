<?php
/**
 * Plugin Name:       GameIndo Core
 * Plugin URI:        https://gameindo.com
 * Description:        Content model for the GameIndo theme — article meta (pillar, subcategory, read time, featured/spotlight, reads), author profile fields, and the editable esports widgets (live ticker, hot topics, match center, standings), plus the live PandaScore match schedule for six games and the Google Tag Manager container ID. All manageable from wp-admin.
 * Version:           1.4.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            GameIndo
 * License:           GPL-2.0-or-later
 * Text Domain:       gameindo-core
 *
 * @package GameIndo_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'GAMEINDO_CORE_VERSION', '1.4.0' );
define( 'GAMEINDO_CORE_DIR', plugin_dir_path( __FILE__ ) );
define( 'GAMEINDO_CORE_URL', plugin_dir_url( __FILE__ ) );

require_once GAMEINDO_CORE_DIR . 'includes/cpt.php';
require_once GAMEINDO_CORE_DIR . 'includes/post-meta.php';
require_once GAMEINDO_CORE_DIR . 'includes/user-meta.php';
require_once GAMEINDO_CORE_DIR . 'includes/esports-meta.php';
require_once GAMEINDO_CORE_DIR . 'includes/helpers.php';
require_once GAMEINDO_CORE_DIR . 'includes/pandascore.php';
require_once GAMEINDO_CORE_DIR . 'includes/rawg.php';
require_once GAMEINDO_CORE_DIR . 'includes/analytics.php';
require_once GAMEINDO_CORE_DIR . 'includes/rest.php';

if ( is_admin() ) {
	require_once GAMEINDO_CORE_DIR . 'includes/pandascore-admin.php';
	require_once GAMEINDO_CORE_DIR . 'includes/rawg-admin.php';
	require_once GAMEINDO_CORE_DIR . 'includes/analytics-admin.php';
}

/**
 * On activation: register CPTs then flush rewrite rules, and make sure the
 * pillar categories exist with the exact slugs the theme/CSS expect.
 */
function gameindo_core_activate() {
	gameindo_core_register_cpts();
	gameindo_core_ensure_pillars();
	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'gameindo_core_activate' );

function gameindo_core_deactivate() {
	wp_clear_scheduled_hook( 'gameindo_pandascore_cron' );
	wp_clear_scheduled_hook( 'gameindo_pandascore_warm' );
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'gameindo_core_deactivate' );

/**
 * Ensure the pillar categories exist (idempotent). Slugs are fixed; names can
 * be edited freely in wp-admin afterwards.
 *
 * 'home' is the legacy slug for the site's game coverage and stays put so old
 * posts keep their category; 'video-games' is the pillar that now presents it,
 * with its own menu entry and archive. The theme creates any missing pillar
 * term on init too, for sites where this plugin was activated before a pillar
 * was added.
 */
function gameindo_core_ensure_pillars() {
	$pillars = array(
		'home'          => 'Video Game',
		'video-games'   => 'Video Games',
		'esports'       => 'Esports',
		'streamer'      => 'Streamer',
		'tech'          => 'Tech',
		'entertainment' => 'Entertainment',
	);
	foreach ( $pillars as $slug => $name ) {
		if ( ! term_exists( $slug, 'category' ) ) {
			wp_insert_term( $name, 'category', array( 'slug' => $slug ) );
		}
	}
}

/**
 * Small admin grouping menu so the esports widgets are easy to find.
 */
function gameindo_core_admin_menu() {
	add_menu_page(
		__( 'GameIndo', 'gameindo-core' ),
		__( 'GameIndo', 'gameindo-core' ),
		'edit_posts',
		'gameindo',
		'gameindo_core_dashboard_page',
		'dashicons-games',
		25
	);
}
add_action( 'admin_menu', 'gameindo_core_admin_menu' );

function gameindo_core_dashboard_page() {
	echo '<div class="wrap"><h1>GameIndo Core</h1>';
	echo '<p>Kelola konten dinamis GameIndo dari sini:</p><ul style="list-style:disc;margin-left:20px">';
	echo '<li><a href="' . esc_url( admin_url( 'edit.php?post_type=gi_ticker' ) ) . '">Live Ticker</a> — <em>tidak lagi dipakai.</em> Teks berjalan di atas header kini terisi otomatis dari 12 artikel terbaru, jadi item di menu ini tidak muncul di situs.</li>';
	echo '<li><a href="' . esc_url( admin_url( 'edit.php?post_type=gi_topic' ) ) . '">Topik Hangat</a> — chip topik di bawah header home.</li>';
	echo '<li><a href="' . esc_url( admin_url( 'admin.php?page=gameindo-pandascore' ) ) . '">PandaScore</a> — sumber utama jadwal match (ML:BB, CS:GO, Valorant, LoL, DotA 2, Overwatch). Isi token di sini.</li>';
	echo '<li><a href="' . esc_url( admin_url( 'admin.php?page=gameindo-rawg' ) ) . '">RAWG</a> — daftar <em>Rilis Mendatang</em> di halaman Video Games. Isi API key di sini; kalau kosong, panelnya tidak muncul.</li>';
	echo '<li><a href="' . esc_url( admin_url( 'admin.php?page=gameindo-analytics' ) ) . '">Analytics</a> — Container ID Google Tag Manager. GA4 dan tag lain diatur di dashboard GTM, bukan di sini.</li>';
	echo '<li><a href="' . esc_url( admin_url( 'edit.php?post_type=gi_match' ) ) . '">Match Center</a> — jadwal manual. Hanya dipakai sebagai <em>cadangan</em> kalau PandaScore mati atau tokennya kosong.</li>';
	echo '<li><a href="' . esc_url( admin_url( 'edit.php?post_type=gi_standing' ) ) . '">Klasemen</a> — <em>tidak lagi ditampilkan.</em> Panel klasemen di halaman Esports sudah diganti panel Jadwal; data lama tetap tersimpan di sini.</li>';
	echo '</ul>';
	echo '<p>Artikel biasa dikelola di menu <strong>Pos</strong>; setiap artikel punya panel <em>GameIndo — Meta Artikel</em> untuk pilar, subkategori, unggulan, dsb.</p>';
	echo '</div>';
}
